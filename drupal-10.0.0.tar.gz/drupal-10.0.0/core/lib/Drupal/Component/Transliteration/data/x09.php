<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, 'N', 'N', 'h', NULL, 'a', 'a', 'i', 'i', 'u', 'u', 'r', 'l', 'e', 'e', 'e',
  0x10 => 'ai', 'o', 'o', 'o', 'au', 'ka', 'kha', 'ga', 'gha', 'na', 'ca', 'cha', 'ja', 'jha', 'na', 'ta',
  0x20 => 'tha', 'da', 'dha', 'na', 'ta', 'tha', 'da', 'dha', 'na', 'na', 'pa', 'pha', 'ba', 'bha', 'ma', 'ya',
  0x30 => 'ra', 'ra', 'la', 'la', 'la', 'va', 'sa', 'sa', 'sa', 'ha', NULL, NULL, '\'', '\'', 'a', 'i',
  0x40 => 'i', 'u', 'uu', 'R', 'RR', 'eN', 'e', 'e', 'ai', 'o', 'o', 'o', 'au', '', NULL, NULL,
  0x50 => '\'om', '\'', '\'', '`', '\'', NULL, NULL, NULL, 'ka', 'kha', 'ga', 'ja', 'da', 'dha', 'pha', 'ya',
  0x60 => 'r', 'l', 'L', 'LL', '.', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => '.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x80 => NULL, 'N', 'm', 'h', NULL, 'a', 'a', 'i', 'i', 'u', 'u', 'r', 'l', NULL, NULL, 'e',
  0x90 => 'ai', NULL, NULL, 'o', 'au', 'ka', 'kha', 'ga', 'gha', 'na', 'ca', 'cha', 'ja', 'jha', 'na', 'ta',
  0xA0 => 'tha', 'da', 'dha', 'na', 'ta', 'tha', 'da', 'dha', 'na', NULL, 'pa', 'pha', 'ba', 'bha', 'ma', 'ya',
  0xB0 => 'ra', NULL, 'la', NULL, NULL, NULL, 'sa', 'sa', 'sa', 'ha', NULL, NULL, '\'', NULL, 'a', 'i',
  0xC0 => 'i', 'u', 'uu', 'R', 'RR', NULL, NULL, 'e', 'ai', NULL, NULL, 'o', 'au', '', 't', NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, '+', NULL, NULL, NULL, NULL, 'da', 'dha', NULL, 'ya',
  0xE0 => 'r', 'l', 'L', 'LL', NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => 'ra', 'ra', 'Rs', 'Rs', '1/', '2/', '3/', '4/', ' 1 - 1/', '/16', '', NULL, NULL, NULL, NULL, NULL,
];
